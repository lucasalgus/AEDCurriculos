package com.company;

public class CelulaCandidato {

    Candidato item;
    CelulaCandidato proximo;

    CelulaCandidato(){
        item = new Candidato();
        proximo = null;
    }

}
