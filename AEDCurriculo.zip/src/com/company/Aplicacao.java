package com.company;

import java.util.Scanner;

public class Aplicacao {
    public static void main(String[] args) {
        new CLI();
    }
}
