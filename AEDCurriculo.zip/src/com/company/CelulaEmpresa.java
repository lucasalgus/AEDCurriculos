package com.company;

public class CelulaEmpresa {
    Empresa item;
    CelulaEmpresa proximo;

    CelulaEmpresa(){
        item = new Empresa();
        proximo = null;
    }
}
