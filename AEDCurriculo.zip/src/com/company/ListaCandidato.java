package com.company;

public class ListaCandidato {
    private CelulaCandidato primeiro;
    private CelulaCandidato ultimo;

    public ListaCandidato() {
        primeiro = new CelulaCandidato();
        ultimo = primeiro;
    }

    public void inserirFinal(Candidato c) {
        CelulaCandidato aux = new CelulaCandidato();
        ultimo.proximo = aux;
        aux.item = c;
        ultimo = ultimo.proximo;
    }

    public Candidato retirar(int identidade) {
        CelulaCandidato aux, anterior;
        anterior = primeiro;
        aux = primeiro.proximo;

        while (aux != null) {
            if (aux.item.getIdentidade() == identidade) {
                anterior.proximo = aux.proximo;

                if (aux == ultimo) {
                    ultimo = anterior;
                }

                return aux.item;
            } else {
                anterior = aux;
                aux = aux.proximo;
            }
        }
        return null;
    }

    public Candidato localizar(int identidade) {
        CelulaCandidato aux;
        aux = primeiro.proximo;

        while (aux != null) {
            if (aux.item.getIdentidade() == identidade) {
                return aux.item;
            } else {
                aux = aux.proximo;
            }
        }

        return null;
    }

    public boolean listaVazia() {
        return primeiro == ultimo;
    }

    private int comprimento(int comprimento, CelulaCandidato celula) {
        if (celula.proximo == null) {
            return 1;
        }

        return comprimento(comprimento, celula.proximo) + 1;
    }

    public int getComprimento() {
        int c = comprimento(0, primeiro.proximo);;
        return c;
    }

    public String serializarLista() {
        StringBuilder dados = new StringBuilder();

        CelulaCandidato aux;
        aux = primeiro.proximo;

        while (aux != null) {
            dados.append(aux.item.toString());
            if (aux.proximo != null) {
                dados.append("\n");
            }
            aux = aux.proximo;
        }

        return dados.toString();
    }

    public int getQuantPorSexo(char sexo) {
        int comprimento = 0;

        CelulaCandidato aux;
        aux = primeiro.proximo;

        while (aux != null) {
            if (aux.item.getSexo() == sexo) {
                comprimento++;
            }

            aux = aux.proximo;
        }

        return comprimento;
    }

    public float getPorcentPorSexo(char sexo) {
        return (float) (getQuantPorSexo(sexo) * 100.0 / getComprimento() * 1.0);
    }

    public int getQuantPorEscolaridade(String escolaridade) {
        int comprimento = 0;

        CelulaCandidato aux;
        aux = primeiro.proximo;

        while (aux != null) {
            if (aux.item.getEscolaridade().equals(escolaridade)) {
                comprimento++;
            }

            aux = aux.proximo;
        }

        return comprimento;
    }

    public float getPorcentPorEscolaridade(String escolaridade) {
        return (float) (getQuantPorEscolaridade(escolaridade) * 100.0 / getComprimento() * 1.0);
    }
}
